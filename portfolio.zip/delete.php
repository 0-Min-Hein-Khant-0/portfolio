<?php
include ("mysql.php");

if (isset($_GET['cid'])) {
	$id  = $_GET['cid'];
	$sql = "DELETE FROM users where id=?";

	$res = $pdo->prepare($sql)->execute([$id]);

	header('Location:minheinkhant_admin.php?delete=success');

}

?>