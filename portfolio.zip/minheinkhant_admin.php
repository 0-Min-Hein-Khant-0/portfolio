<?php

require 'mysql.php';

?>
<?php error_reporting(E_ALL^E_NOTICE);?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>ADMIN</title>
	<!-- Font Awesome -->
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
<!-- Google Fonts -->
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap">
<!-- Bootstrap core CSS -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.0/css/bootstrap.min.css" rel="stylesheet">
<!-- Material Design Bootstrap -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.19.1/css/mdb.min.css" rel="stylesheet">
</head>
<body>


<div class="container">
	<div class="row">

		<div class="col-md-12">
				<a href="index.php" class="btn btn-outline-dark">Back</a>
			<div class="card mt-5">
				<h3 class="text-center text-success mt-3">All Message</h3>

				<hr>
<?php
//if(isset($_GET['create']))
if ($_GET['delete']) {

	?>
	<div class="alert alert-danger alert-dismissible fade show text-center">
								                <strong>Successful Deleted</strong>
								                    <button class="close" data-dismiss="alert">&times;</button>
								                </div>
	<?php

}

?>
<div class="card-body">
					<table class="table table-striped table-bordered table-hover text-secondary">
						<thead>
							<tr>
							<th>id</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Subject</th>
                            <th>Message</th>
                            <th>Time</th>
                            <th>Options</th>
                            </tr>
						</thead>
						<tbody>
<?php

$sql  = "SELECT * FROM users";
$data = $pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);
//print_r($data);

$i = 1;
foreach ($data as $d) {

	?>

																																																		<tr>
																																																			<td><?=$i++?></td>
																																																			<td><?=$d['name']?></td>
																																																			<td><?=$d['email']?></td>
																																																			<td><?=$d['subject']?></td>
																																																			<td><?=$d['message']?></td>
																																																			<td><?=$d['created_up']?></td>
																																																			<td>
																																																				<a href="delete.php?cid=<?=$d['id']?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Are you sure you want to delete?')";>Delete</a>
																																																			</td>

																																																		</tr>

	<?php

}

?>
</tbody>
                    </table>
				</div>
			</div>

		</div>

	</div>
</div>










<!-- JQuery -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<!-- Bootstrap tooltips -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.4/umd/popper.min.js"></script>
<!-- Bootstrap core JavaScript -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.0/js/bootstrap.min.js"></script>
<!-- MDB core JavaScript -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.19.1/js/mdb.min.js"></script>
</body>
</html>
</body>
</html>